  // Select the element containing the estimated arrival time
var arrivalTimeElements = document.querySelectorAll('.delay-light, .delay-medium, .delay-heavy');

// Function to update the arrival time
function updateArrivalTime() {
  arrivalTimeElements.forEach(function(element) {
    if (!element.innerHTML.endsWith("insha'Allah")) {
      element.innerHTML += ' insha\'Allah';
    }
  });
}

// Create a MutationObserver to watch for changes to the page
var observer = new MutationObserver(function(mutations) {
  // Update the arrival time elements on each mutation
  updateArrivalTime();
});

// Start observing the page
observer.observe(document.body, { childList: true, subtree: true });